package com.perficient.adobe.visionapi.core.impl;

import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.vision.v1.Vision;
import com.google.api.services.vision.v1.VisionScopes;
import com.google.api.services.vision.v1.model.AnnotateImageRequest;
import com.google.api.services.vision.v1.model.AnnotateImageResponse;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesRequest;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesResponse;
import com.google.api.services.vision.v1.model.EntityAnnotation;
import com.google.api.services.vision.v1.model.FaceAnnotation;
import com.google.api.services.vision.v1.model.Feature;
import com.google.api.services.vision.v1.model.Image;
import com.google.common.collect.ImmutableList;
import com.perficient.adobe.visionapi.core.VisionService;

// TODO: Auto-generated Javadoc
/**
 * The Class VisionServiceImpl.
 */
@Component(immediate = true)
@Properties({ @Property(name = Constants.SERVICE_DESCRIPTION, value = "Vision Service"),
		@Property(name = Constants.SERVICE_VENDOR, value = "Perficient") })
@Service(value = VisionService.class)
public class VisionServiceImpl implements VisionService {

	/** The Constant LOG. */
	private final static Logger LOG = LoggerFactory.getLogger(VisionServiceImpl.class);

	/**
	 * Gets the annotationsfor binary content.
	 *
	 * @param binaryContent
	 *            the binary content
	 * @param maxResults
	 *            the max results
	 * @return the annotationsfor binary content
	 */
	/*
	 * (non-Javadoc)
	 *
	 * @see com.perficient.adobe.visionapi.core.VisionService#
	 * getLabelsforBinaryContent(byte[], int)
	 */
	public List<EntityAnnotation> getAnnotationsforBinaryContent(byte[] binaryContent, int maxResults,
			VisionFeature visionFeature) {
		if (LOG.isDebugEnabled()) {
			LOG.debug(
					"getAnnotationsforBinaryContent(byte[], int, VisionFeature) - start - " + visionFeature.toString()); //$NON-NLS-1$
		}
		List<EntityAnnotation> entityAnnotations = new ArrayList<EntityAnnotation>();

		Vision vision;
		try {

			vision = getVisionService();

			AnnotateImageRequest annotateImageRequest = new AnnotateImageRequest()
					.setImage(new Image().encodeContent(binaryContent)).setFeatures(ImmutableList
							.of(new Feature().setType(visionFeature.toString()).setMaxResults(maxResults)));

			Vision.Images.Annotate annotate = vision.images()
					.annotate(new BatchAnnotateImagesRequest().setRequests(ImmutableList.of(annotateImageRequest)));
			// Due to a bug: requests to Vision API containing large images fail
			// when GZipped.

			annotate.setDisableGZipContent(true);
			BatchAnnotateImagesResponse batchResponse = annotate.execute();
			assert batchResponse.getResponses().size() == 1;
			AnnotateImageResponse response = batchResponse.getResponses().get(0);
			if (visionFeature == VisionFeature.LABEL_DETECTION) {
				List<EntityAnnotation> labelAnnotations = response.getLabelAnnotations();
				if (labelAnnotations != null) {
					entityAnnotations = labelAnnotations;
				}
			} else if (visionFeature == VisionFeature.LANDMARK_DETECTION) {
				List<EntityAnnotation> landmarkAnnotations = response.getLandmarkAnnotations();
				if (landmarkAnnotations != null) {
					entityAnnotations = landmarkAnnotations;
				}
			} else if (visionFeature == VisionFeature.LOGO_DETECTION) {
				List<EntityAnnotation> logoAnnotations = response.getLogoAnnotations();
				if (logoAnnotations != null) {
					entityAnnotations = logoAnnotations;
				}
			} else if (visionFeature == VisionFeature.TEXT_DETECTION) {
				List<EntityAnnotation> textAnnotations = response.getTextAnnotations();
				if (textAnnotations != null) {
					entityAnnotations = textAnnotations;
				}
			}
		} catch (IOException e) {
			LOG.error("getAnnotationsforBinaryContent(byte[], int, VisionFeature)", e); //$NON-NLS-1$

			LOG.error(ExceptionUtils.getStackTrace(e));
		} catch (GeneralSecurityException e) {
			LOG.error("getAnnotationsforBinaryContent(byte[], int, VisionFeature)", e); //$NON-NLS-1$

			LOG.error(ExceptionUtils.getStackTrace(e));
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("getAnnotationsforBinaryContent(byte[], int, VisionFeature) - end - " + visionFeature.toString()); //$NON-NLS-1$
		}
		return entityAnnotations;

	}

	/**
	 * Gets the face annotationsfor binary content.
	 *
	 * @param binaryContent
	 *            the binary content
	 * @param maxResults
	 *            the max results
	 * @return the face annotationsfor binary content
	 */
	public List<EntityAnnotation> getFaceAnnotationsforBinaryContent(byte[] binaryContent, int maxResults) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("getFaceAnnotationsforBinaryContent(byte[], int, VisionFeature) - start - " + "FACE_DETECTION"); //$NON-NLS-1$
		}
		List<EntityAnnotation> entityAnnotations = new ArrayList<EntityAnnotation>();

		Vision vision;
		try {

			vision = getVisionService();

			AnnotateImageRequest annotateImageRequest = new AnnotateImageRequest()
					.setImage(new Image().encodeContent(binaryContent))
					.setFeatures(ImmutableList.of(new Feature().setType("FACE_DETECTION").setMaxResults(maxResults)));

			Vision.Images.Annotate annotate = vision.images()
					.annotate(new BatchAnnotateImagesRequest().setRequests(ImmutableList.of(annotateImageRequest)));
			// Due to a bug: requests to Vision API containing large images fail
			// when GZipped.

			annotate.setDisableGZipContent(true);
			BatchAnnotateImagesResponse batchResponse = annotate.execute();
			assert batchResponse.getResponses().size() == 1;
			AnnotateImageResponse response = batchResponse.getResponses().get(0);

			List<FaceAnnotation> faceAnnotations = response.getFaceAnnotations();
			if (faceAnnotations != null) {
				for (FaceAnnotation faceAnnotation : faceAnnotations) {
					LOG.info(faceAnnotation.toPrettyString());
					if (!faceAnnotation.getAngerLikelihood().contains("UNLIKELY")) {
						EntityAnnotation entityAnnotation = new EntityAnnotation();
						entityAnnotation.setDescription("angry");
						entityAnnotations.add(entityAnnotation);
					}
					if (!faceAnnotation.getBlurredLikelihood().contains("UNLIKELY")) {
						EntityAnnotation entityAnnotation = new EntityAnnotation();
						entityAnnotation.setDescription("blurry");
						entityAnnotations.add(entityAnnotation);
					}
					if (!faceAnnotation.getHeadwearLikelihood().contains("UNLIKELY")) {
						EntityAnnotation entityAnnotation = new EntityAnnotation();
						entityAnnotation.setDescription("headwear");
						entityAnnotations.add(entityAnnotation);
					}
					if (!faceAnnotation.getJoyLikelihood().contains("UNLIKELY")) {
						EntityAnnotation entityAnnotation = new EntityAnnotation();
						entityAnnotation.setDescription("joyful");
						entityAnnotations.add(entityAnnotation);
					}
					if (!faceAnnotation.getSorrowLikelihood().contains("UNLIKELY")) {
						EntityAnnotation entityAnnotation = new EntityAnnotation();
						entityAnnotation.setDescription("sad");
						entityAnnotations.add(entityAnnotation);
					}
					if (!faceAnnotation.getSurpriseLikelihood().contains("UNLIKELY")) {
						EntityAnnotation entityAnnotation = new EntityAnnotation();
						entityAnnotation.setDescription("surprised");
						entityAnnotations.add(entityAnnotation);
					}
					if (!faceAnnotation.getUnderExposedLikelihood().contains("UNLIKELY")) {
						EntityAnnotation entityAnnotation = new EntityAnnotation();
						entityAnnotation.setDescription("under exposed");
						entityAnnotations.add(entityAnnotation);
					}
				}
			}

		} catch (IOException e) {
			LOG.error("getAnnotationsforBinaryContent(byte[], int, VisionFeature)", e); //$NON-NLS-1$

			LOG.error(ExceptionUtils.getStackTrace(e));
		} catch (GeneralSecurityException e) {
			LOG.error("getFaceAnnotationsforBinaryContent(byte[], int, VisionFeature)", e); //$NON-NLS-1$

			LOG.error(ExceptionUtils.getStackTrace(e));
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("getFaceAnnotationsforBinaryContent(byte[], int, VisionFeature) - end - " + "FACE_DETECTION"); //$NON-NLS-1$
		}
		return entityAnnotations;

	}

	/**
	 * Gets the vision service.
	 *
	 * @return the vision service
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws GeneralSecurityException
	 *             the general security exception
	 */
	private Vision getVisionService() throws IOException, GeneralSecurityException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("getVisionService() - start"); //$NON-NLS-1$
		}
		InputStream credentialsJson = this.getClass().getResourceAsStream("/VisionApiServiceAccount.json");
		JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();
		HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
		GoogleCredential credential = GoogleCredential.fromStream(credentialsJson, httpTransport, jsonFactory)
				.createScoped(VisionScopes.all());
		Vision returnVision = new Vision.Builder(GoogleNetHttpTransport.newTrustedTransport(), jsonFactory, credential)
				.setApplicationName(APPLICATION_NAME).build();
		if (LOG.isDebugEnabled()) {
			LOG.debug("getVisionService() - end"); //$NON-NLS-1$
		}
		return returnVision;
	}

}
