package com.perficient.adobe.visionapi.core.workflow;

import java.io.IOException;
import java.io.InputStream;
import java.security.AccessControlException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.day.cq.dam.commons.util.DamUtil;
import com.day.cq.tagging.InvalidTagFormatException;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import com.github.slugify.Slugify;
import com.google.api.services.vision.v1.model.EntityAnnotation;
import com.perficient.adobe.visionapi.core.VisionService;
import com.perficient.adobe.visionapi.core.VisionService.VisionFeature;
import com.perficient.adobe.visionapi.core.dam.RenditionPatternPicker;

// TODO: Auto-generated Javadoc
/**
 * The Class AddGoogleCloudVisionTags.
 */
@Component
@Service
@Properties({ @Property(name = Constants.SERVICE_VENDOR, value = "Perficient"),
		@Property(name = "process.label", value = "Add Google Cloud Vision Tags to Dam Asset") })
public class AddGoogleCloudVisionTags implements WorkflowProcess {

	/** The Constant DEFAULT_ASSET_RENDITION_PICKER_REGEX. */
	private static final String DEFAULT_ASSET_RENDITION_PICKER_REGEX = "cq5dam\\.web\\.(.*)";

	/** The Constant LOG. */
	private final static Logger LOG = LoggerFactory.getLogger(AddGoogleCloudVisionTags.class);

	/** The resource resolver factory. */
	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	/** The tag manager. */
	private TagManager tagManager;

	/** The vision service. */
	@Reference
	private VisionService visionService;

	/**
	 * Adds the tags.
	 *
	 * @param newTags
	 *            the new tags
	 * @param metaDataResource
	 *            the meta data resource
	 */
	private void addTags(Tag[] newTags, Resource metaDataResource) {
		if (newTags.length > 0) {
			Tag[] oldTags = tagManager.getTags(metaDataResource);
			Tag[] tags = (Tag[]) ArrayUtils.addAll(oldTags, newTags);
			tagManager.setTags(metaDataResource, tags, true);
		}
	}

	/**
	 * Annotations to tags.
	 *
	 * @param entityAnnotations
	 *            the entity annotations
	 * @param visionFeature
	 *            the vision feature
	 * @return the tag[]
	 */
	private Tag[] annotationsToTags(List<EntityAnnotation> entityAnnotations, VisionFeature visionFeature) {
		List<Tag> tags = new ArrayList<Tag>();
		String containerTag = StringUtils.EMPTY;
		switch (visionFeature.ordinal()) {
		case 0:
			containerTag = "face";
			break;
		case 1:
			containerTag = "label";
			break;
		case 2:
			containerTag = "landmark";
			break;
		case 3:
			containerTag = "logo";
			break;
		case 4:
			containerTag = "text";
			break;
		}

		try {
			Slugify slug = new Slugify();
			for (EntityAnnotation entityAnnotation : entityAnnotations) {
				String entityDescription = entityAnnotation.getDescription();
				LOG.info(entityDescription + " (score: " + entityAnnotation.getScore() + ")");
				if (StringUtils.isNotEmpty(entityDescription)) {
					String tagId = slug.slugify(entityDescription);
					String fullTagId = "vision:" + containerTag + "/" + tagId;
					Tag existing = tagManager.resolve(fullTagId);
					if (existing != null) {
						tags.add(existing);
					} else {
						Tag tag = tagManager.createTag(fullTagId, WordUtils.capitalizeFully(entityDescription),
								StringUtils.EMPTY);
						tags.add(tag);
					}
				}
			}
		} catch (IOException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		} catch (AccessControlException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		} catch (InvalidTagFormatException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		}
		return tags.toArray(new Tag[tags.size()]);

	}

	/**
	 * Call vision api for resource.
	 *
	 * @param workflowSession
	 *            the workflow session
	 * @param imageResource
	 *            the image resource
	 * @throws RepositoryException
	 *             the repository exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws LoginException
	 *             the login exception
	 */
	private void callVisionApiForResource(WorkflowSession workflowSession, Resource imageResource)
			throws RepositoryException, IOException, LoginException {
		ResourceResolver resourceResolver = getResourceResolver(workflowSession.getSession());
		if (imageResource != null) {
			Asset asset = DamUtil.resolveToAsset(imageResource);
			if (asset != null) {
				LOG.info("Image Resource Path: " + imageResource.getPath());
				Node imageNode = imageResource.adaptTo(Node.class);
				String assetPath = asset.getPath();
				assetPath = assetPath + "/jcr:content/metadata";
				Resource metaDataResource = resourceResolver.getResource(assetPath);

				if (metaDataResource != null) {
					Node metaDataNode = metaDataResource.adaptTo(Node.class);

					InputStream inputStream = imageNode.getProperty("jcr:data").getBinary().getStream();
					byte[] bytes = IOUtils.toByteArray(inputStream);

					VisionFeature visionFeature = VisionFeature.LABEL_DETECTION;
					List<EntityAnnotation> entityAnnotations = visionService.getAnnotationsforBinaryContent(bytes, 10,
							visionFeature);
					addTags(annotationsToTags(entityAnnotations, visionFeature), metaDataResource);

					visionFeature = VisionFeature.LANDMARK_DETECTION;
					entityAnnotations = visionService.getAnnotationsforBinaryContent(bytes, 10, visionFeature);
					addTags(annotationsToTags(entityAnnotations, visionFeature), metaDataResource);

					visionFeature = VisionFeature.LOGO_DETECTION;
					entityAnnotations = visionService.getAnnotationsforBinaryContent(bytes, 10, visionFeature);
					addTags(annotationsToTags(entityAnnotations, visionFeature), metaDataResource);

					visionFeature = VisionFeature.FACE_DETECTION;
					entityAnnotations = visionService.getFaceAnnotationsforBinaryContent(bytes, 10);
					addTags(annotationsToTags(entityAnnotations, visionFeature), metaDataResource);

					visionFeature = VisionFeature.TEXT_DETECTION;
					entityAnnotations = visionService.getAnnotationsforBinaryContent(bytes, 10, visionFeature);

					StringBuffer textBuffer = new StringBuffer();

					for (int index = 0; index < entityAnnotations.size(); index++) {
						if (index != 0) {
							EntityAnnotation entityAnnotation = entityAnnotations.get(index);
							String entityDescription = entityAnnotation.getDescription();
							textBuffer.append(entityDescription).append(", ");
						}
					}

					String textInImage = textBuffer.toString();
					String description = StringUtils.EMPTY;
					LOG.info(textInImage);
					if (textInImage.length() > 0) {
						textInImage = StringUtils.stripEnd(textInImage, ", ");
						if (metaDataNode.hasProperty("dc:description")) {
							description = metaDataNode.getProperty("dc:description").getString();
							description = description.replaceAll("\\[.*\\]", "");
						}
						metaDataNode.setProperty("dc:description",
								(description + " [Text in image: " + textInImage + "]").trim());
						resourceResolver.adaptTo(Session.class).save();
					}
				}

			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.day.cq.workflow.exec.WorkflowProcess#execute(com.day.cq.workflow.exec
	 * .WorkItem, com.day.cq.workflow.WorkflowSession,
	 * com.day.cq.workflow.metadata.MetaDataMap)
	 */
	@Override
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)
			throws WorkflowException {
		LOG.info("Starting " + this.getClass());
		try {
			ResourceResolver resourceResolver = getResourceResolver(workflowSession.getSession());
			tagManager = resourceResolver.adaptTo(TagManager.class);
			Resource resource = getResourceFromPayload(workflowSession, workItem);
			if (null != resource) {
				Asset asset = DamUtil.resolveToAsset(resource);
				Rendition rendition = asset.getOriginal();
				if (rendition.getSize() > 500000) {
					rendition = asset.getRendition(new RenditionPatternPicker(DEFAULT_ASSET_RENDITION_PICKER_REGEX));
				}
				callVisionApiForResource(workflowSession, rendition);
			}
		} catch (Exception e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		}

		LOG.info("Ending " + this.getClass());

	}

	/**
	 * Gets the resource from payload.
	 *
	 * @param workflowSession
	 *            the workflow session
	 * @param item
	 *            the item
	 * @return the resource from payload
	 * @throws LoginException
	 *             the login exception
	 */
	private Resource getResourceFromPayload(WorkflowSession workflowSession, WorkItem item) throws LoginException {
		ResourceResolver resourceResolver = getResourceResolver(workflowSession.getSession());
		Resource resource = null;
		if (item.getWorkflowData().getPayloadType().equals("JCR_PATH")) {
			String path = item.getWorkflowData().getPayload().toString();
			resource = resourceResolver.getResource(path);
		}
		return resource;
	}

	/**
	 * Gets the resource resolver.
	 *
	 * @param session
	 *            the session
	 * @return the resource resolver
	 * @throws LoginException
	 *             the login exception
	 */
	private ResourceResolver getResourceResolver(Session session) throws LoginException {
		return resourceResolverFactory.getResourceResolver(
				Collections.<String, Object> singletonMap(JcrResourceConstants.AUTHENTICATION_INFO_SESSION, session));
	}

}
