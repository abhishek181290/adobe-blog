package com.perficient.adobe.visionapi.core;

import java.util.List;

import com.google.api.services.vision.v1.model.EntityAnnotation;

// TODO: Auto-generated Javadoc
/**
 * The Interface VisionService.
 */
public interface VisionService {

	/**
	 * The Enum VisionFeature.
	 */
	enum VisionFeature {

		/** The face detection. */
		FACE_DETECTION,

		/** The label detection. */
		LABEL_DETECTION,

		/** The landmark detection. */
		LANDMARK_DETECTION,

		/** The logo detection. */
		LOGO_DETECTION,

		/** The text detection. */
		TEXT_DETECTION
	};

	/** The Constant APPLICATION_NAME. */
	static final String APPLICATION_NAME = "VisonAPI/1.0";

	/**
	 * Gets the annotationsfor binary content.
	 *
	 * @param binaryContent the binary content
	 * @param maxResults the max results
	 * @param visionFeature the vision feature
	 * @return the annotationsfor binary content
	 */
	List<EntityAnnotation> getAnnotationsforBinaryContent(byte[] binaryContent, int maxResults,
			VisionFeature visionFeature);

	/**
	 * Gets the face annotationsfor binary content.
	 *
	 * @param binaryContent the binary content
	 * @param maxResults the max results
	 * @return the face annotationsfor binary content
	 */
	List<EntityAnnotation> getFaceAnnotationsforBinaryContent(byte[] binaryContent, int maxResults);
}
