/*
 *  Copyright 2015 Adobe Systems Incorporated
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.perficient.adobe.visionapi.core.listeners;

import java.io.IOException;
import java.io.InputStream;
import java.security.AccessControlException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.SimpleCredentials;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.commons.util.DamUtil;
import com.day.cq.tagging.InvalidTagFormatException;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.github.slugify.Slugify;
import com.google.api.services.vision.v1.model.EntityAnnotation;
import com.perficient.adobe.visionapi.core.VisionService;
import com.perficient.adobe.visionapi.core.VisionService.VisionFeature;

// TODO: Auto-generated Javadoc
/**
 * The listener interface for receiving damAssetNode events. The class that is
 * interested in processing a damAssetNode event implements this interface, and
 * the object created with that class is registered with a component using the
 * component's <code>addDamAssetNodeListener<code> method. When the damAssetNode
 * event occurs, that object's appropriate method is invoked.
 *
 * @see DamAssetNodeEvent
 */
@Component
public class DamAssetNodeListener implements EventListener {

	/** The Constant DEFAULT_ASSET_RENDITION_PICKER_REGEX. */
	private static final String DEFAULT_ASSET_RENDITION_PICKER_REGEX = "cq5dam\\.web\\.(.*)";

	/** The admin session. */
	private Session adminSession;

	/** The log. */
	Logger LOG = LoggerFactory.getLogger(this.getClass());

	/** The repository. */
	@Reference
	SlingRepository repository;

	/** The resource resolver factory. */
	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	/** The use rendition. */
	boolean useRendition = false;

	/** The vision service. */
	@Reference
	private VisionService visionService;

	/**
	 * Activate.
	 *
	 * @param context
	 *            the context
	 */
	@Activate
	public void activate(ComponentContext context) {
		LOG.info("activating DamAssetNodeListener");
		adminSession = null;
		try {
			// session = resourceResolver.adaptTo(Session.class);
			final String[] types = { "nt:file" };
			ResourceResolver resourceResolver = getResourceResolver();
			Session jcrSession = resourceResolver.adaptTo(Session.class);
			adminSession = jcrSession.impersonate(new SimpleCredentials("admin", "".toCharArray()));
			adminSession.getWorkspace().getObservationManager().addEventListener(this, // handler
					Event.NODE_ADDED, // binary
										// combination
										// of event
										// types
					"/content/dam", // path
					true, // is Deep?
					null, // uuids filter
					types, // nodetypes filter
					false);
		} catch (RepositoryException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * Adds the tags.
	 *
	 * @param newTags
	 *            the new tags
	 * @param metaDataResource
	 *            the meta data resource
	 */
	private void addTags(Tag[] newTags, Resource metaDataResource) {
		TagManager tagManager = getResourceResolverFromSession(adminSession).adaptTo(TagManager.class);
		if (newTags.length > 0) {
			Tag[] oldTags = tagManager.getTags(metaDataResource);
			Tag[] tags = (Tag[]) ArrayUtils.addAll(oldTags, newTags);
			tagManager.setTags(metaDataResource, tags, true);
		}
	}

	/**
	 * Annotations to tags.
	 *
	 * @param entityAnnotations
	 *            the entity annotations
	 * @param visionFeature
	 *            the vision feature
	 * @return the tag[]
	 */
	private Tag[] annotationsToTags(List<EntityAnnotation> entityAnnotations, VisionFeature visionFeature) {
		TagManager tagManager = getResourceResolverFromSession(adminSession).adaptTo(TagManager.class);
		List<Tag> tags = new ArrayList<Tag>();
		String containerTag = StringUtils.EMPTY;
		switch (visionFeature.ordinal()) {
		case 0:
			containerTag = "face";
			break;
		case 1:
			containerTag = "label";
			break;
		case 2:
			containerTag = "landmark";
			break;
		case 3:
			containerTag = "logo";
			break;
		case 4:
			containerTag = "text";
			break;
		}

		try {
			Slugify slug = new Slugify();
			for (EntityAnnotation entityAnnotation : entityAnnotations) {
				String entityDescription = entityAnnotation.getDescription();
				LOG.info(entityDescription + " (score: " + entityAnnotation.getScore() + ")");
				if (StringUtils.isNotEmpty(entityDescription)) {
					String tagId = slug.slugify(entityDescription);
					String fullTagId = "vision:" + containerTag + "/" + tagId;
					Tag existing = tagManager.resolve(fullTagId);
					if (existing != null) {
						tags.add(existing);
					} else {
						Tag tag = tagManager.createTag(fullTagId, WordUtils.capitalizeFully(entityDescription),
								StringUtils.EMPTY);
						tags.add(tag);
					}
				}
			}
		} catch (IOException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		} catch (AccessControlException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		} catch (InvalidTagFormatException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		}
		return tags.toArray(new Tag[tags.size()]);

	}

	/**
	 * Call vision api for resource.
	 *
	 * @param imageResource
	 *            the image resource
	 * @throws RepositoryException
	 *             the repository exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private void callVisionApiForResource(Resource imageResource) throws RepositoryException, IOException {
		ResourceResolver resourceResolver = getResourceResolverFromSession(adminSession);
		if (imageResource != null) {
			Asset asset = DamUtil.resolveToAsset(imageResource);
			if (asset != null) {
				LOG.info("Image Resource Path: " + imageResource.getPath());
				Node imageNode = imageResource.adaptTo(Node.class);
				String assetPath = asset.getPath();
				assetPath = assetPath + "/jcr:content/metadata";
				Resource metaDataResource = resourceResolver.getResource(assetPath);

				if (metaDataResource != null) {
					Node metaDataNode = metaDataResource.adaptTo(Node.class);

					InputStream inputStream = imageNode.getProperty("jcr:data").getBinary().getStream();
					byte[] bytes = IOUtils.toByteArray(inputStream);

					VisionFeature visionFeature = VisionFeature.LABEL_DETECTION;
					List<EntityAnnotation> entityAnnotations = visionService.getAnnotationsforBinaryContent(bytes, 10,
							visionFeature);
					addTags(annotationsToTags(entityAnnotations, visionFeature), metaDataResource);

					visionFeature = VisionFeature.LANDMARK_DETECTION;
					entityAnnotations = visionService.getAnnotationsforBinaryContent(bytes, 10, visionFeature);
					addTags(annotationsToTags(entityAnnotations, visionFeature), metaDataResource);

					visionFeature = VisionFeature.LOGO_DETECTION;
					entityAnnotations = visionService.getAnnotationsforBinaryContent(bytes, 10, visionFeature);
					addTags(annotationsToTags(entityAnnotations, visionFeature), metaDataResource);

					visionFeature = VisionFeature.FACE_DETECTION;
					entityAnnotations = visionService.getFaceAnnotationsforBinaryContent(bytes, 10);
					addTags(annotationsToTags(entityAnnotations, visionFeature), metaDataResource);

					visionFeature = VisionFeature.TEXT_DETECTION;
					entityAnnotations = visionService.getAnnotationsforBinaryContent(bytes, 10, visionFeature);

					StringBuffer textBuffer = new StringBuffer();

					for (int index = 0; index < entityAnnotations.size(); index++) {
						if (index != 0) {
							EntityAnnotation entityAnnotation = entityAnnotations.get(index);
							String entityDescription = entityAnnotation.getDescription();
							textBuffer.append(entityDescription).append(", ");
						}
					}

					String textInImage = textBuffer.toString();
					String description = StringUtils.EMPTY;
					LOG.info(textInImage);
					if (textInImage.length() > 0) {
						textInImage = StringUtils.stripEnd(textInImage, ", ");
						if (metaDataNode.hasProperty("dc:description")) {
							Property property = metaDataNode.getProperty("dc:description");
							description = property.getString();
							description = description.replaceAll("\\[.*\\]", "");
						}
						metaDataNode.setProperty("dc:description",
								(description + " [Text in image: " + textInImage + "]").trim());
						resourceResolver.adaptTo(Session.class).save();
					}
				}

			}
		}
	}

	/**
	 * Deactivate.
	 */
	@Deactivate
	public void deactivate() {
		if (adminSession != null) {
			adminSession.logout();
		}
	}

	/**
	 * Gets the resource resolver.
	 *
	 * @return the resource resolver
	 */
	/*
	 * (non-Javadoc)
	 *
	 * @see com.symantec.cq.unifiedweb.core.JCRUtils#getResourceResolver()
	 */
	private ResourceResolver getResourceResolver() {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put(ResourceResolverFactory.SUBSERVICE, "jcrUtilService");
		ResourceResolver resolver = null;
		try {
			resolver = resourceResolverFactory.getServiceResourceResolver(param);
		} catch (LoginException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		}
		return resolver;
	}

	/**
	 * Gets the resource resolver from session.
	 *
	 * @param session
	 *            the session
	 * @return the resource resolver from session
	 */
	public ResourceResolver getResourceResolverFromSession(final Session session) {

		try {
			return resourceResolverFactory
					.getResourceResolver(Collections.singletonMap("user.jcr.session", (Object) session));
		} catch (LoginException e) {
			throw new IllegalStateException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see javax.jcr.observation.EventListener#onEvent(javax.jcr.observation.
	 * EventIterator)
	 */
	public void onEvent(EventIterator eventIterator) {
		ResourceResolver resourceResolver = getResourceResolver();
		try {
			while (eventIterator.hasNext()) {
				Event event = eventIterator.nextEvent();
				String path = event.getPath();
				String renditionPath = StringUtils.EMPTY;
				if (path.endsWith("/jcr:content")) {
					renditionPath = StringUtils.substringBeforeLast(path, "/jcr:content");
					Resource renditionResource = resourceResolver.getResource(renditionPath);
					if (null != renditionResource) {
						String renditionName = renditionResource.getName();
						Pattern pattern = Pattern.compile(DEFAULT_ASSET_RENDITION_PICKER_REGEX);
						Matcher matcher = pattern.matcher(renditionName);
						Resource imageResource = resourceResolver.getResource(path);

						if (renditionName.equals("original")) {
							useRendition = false;
							Asset asset = DamUtil.resolveToAsset(renditionResource);
							if (asset.getOriginal().getSize() > 500000) {
								useRendition = true;
							} else {
								callVisionApiForResource(imageResource);
							}

						} else if (matcher.find() && useRendition) {
							callVisionApiForResource(imageResource);

						}
					}
				}
			}
		} catch (RepositoryException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		}
	}
}
